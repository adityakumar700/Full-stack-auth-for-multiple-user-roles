(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a903ff61._.js",
  "static/chunks/src_app_signup_page_tsx_63af329b._.js"
],
    source: "dynamic"
});
