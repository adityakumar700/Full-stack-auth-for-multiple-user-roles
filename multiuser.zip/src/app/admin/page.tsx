"use client"
export default function AdminPage() {
  return (
    <div className="p-4">
      <h1 className="text-2xl">Admin Dashboard</h1>
      <p>Welcome admin!</p>
    </div>
  );
}