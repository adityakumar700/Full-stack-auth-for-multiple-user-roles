"use client"
export default function Dashboard() {
  return (
    <div className="p-4">
      <h1 className="text-2xl">User Dashboard</h1>
      <p>Welcome to your dashboard!</p>
    </div>
  );
}